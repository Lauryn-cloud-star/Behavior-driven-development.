# Gherkin Language

# Keyword Name: When
- Use to write actions we want to perform

# Keyword Name: Then
- Use to define validations. Here we are going to match actual result with expected result

# Keyword Name: And
- This keyword will be used with When and Then.
- Use it when you want to define more than one action or verification.

